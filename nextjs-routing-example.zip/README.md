# Next.js Routing Example

This is a simple Next.js project demonstrating:

- Multiple static pages (`index.js`, `about.js`)
- Dynamic routing using `[slug].js` inside `pages/blog/`
- Client-side navigation with Next.js `<Link>` component

---

## Project Structure & Source Code

### `pages/index.js`

```jsx
import Link from 'next/link';

export default function Home() {
  return (
    <main>
      <h1>Home Page</h1>
      <p>Welcome to the Next.js routing example.</p>
      <ul>
        <li>
          <Link href="/about">Go to About Page</Link>
        </li>
        <li>
          <Link href="/blog/first-post">Read Blog: First Post</Link>
        </li>
        <li>
          <Link href="/blog/nextjs-routing">Read Blog: Next.js Routing</Link>
        </li>
      </ul>
    </main>
  );
}
```

---

### `pages/about.js`

```jsx
import Link from 'next/link';

export default function About() {
  return (
    <main>
      <h1>About Page</h1>
      <p>This page is statically routed using file-based routing.</p>
      <Link href="/">← Back to Home</Link>
    </main>
  );
}
```

---

### `pages/blog/[slug].js`

```jsx
import { useRouter } from 'next/router';
import Link from 'next/link';

export default function BlogPost() {
  const router = useRouter();
  const { slug } = router.query;

  return (
    <main>
      <h1>Blog Post: {slug}</h1>
      <p>This blog post is generated dynamically based on the URL.</p>
      <Link href="/">← Back to Home</Link>
    </main>
  );
}
```

---

### `styles/globals.css`

```css
body {
  font-family: sans-serif;
  background: #f9f9f9;
  padding: 2rem;
  margin: 0;
  color: #222;
}

a {
  color: #0070f3;
  text-decoration: none;
}

a:hover {
  text-decoration: underline;
}

ul {
  list-style: none;
  padding: 0;
}

li {
  margin: 0.5rem 0;
}
```

---

### `next.config.js`

```js
/** @type {import('next').NextConfig} */
const nextConfig = {};

module.exports = nextConfig;
```

---

### `package.json`

```json
{
  "name": "my-next-app",
  "version": "1.0.0",
  "private": true,
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "lint": "next lint"
  },
  "dependencies": {
    "next": "latest",
    "react": "latest",
    "react-dom": "latest"
  }
}
```

---

## How to Run

1. Clone or download this repo.
2. Run:

   ```bash
   npm install
   npm run dev
   ```

3. Open your browser and navigate to [http://localhost:3000](http://localhost:3000).

4. Try visiting:

   - `/about`
   - `/blog/first-post`
   - `/blog/nextjs-routing`
