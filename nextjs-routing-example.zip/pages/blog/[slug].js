import { useRouter } from 'next/router';
import Link from 'next/link';

export default function BlogPost() {
  const router = useRouter();
  const { slug } = router.query;

  return (
    <main>
      <h1>Blog Post: {slug}</h1>
      <p>This blog post is generated dynamically based on the URL.</p>
      <Link href="/">← Back to Home</Link>
    </main>
  );
}
