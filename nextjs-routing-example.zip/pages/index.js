import Link from 'next/link';

export default function Home() {
  return (
    <main>
      <h1>Home Page</h1>
      <p>Welcome to the Next.js routing example.</p>
      <ul>
        <li>
          <Link href="/about">Go to About Page</Link>
        </li>
        <li>
          <Link href="/blog/first-post">Read Blog: First Post</Link>
        </li>
        <li>
          <Link href="/blog/nextjs-routing">Read Blog: Next.js Routing</Link>
        </li>
      </ul>
    </main>
  );
}
